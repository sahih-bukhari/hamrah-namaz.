package com.mydeen.companion;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
