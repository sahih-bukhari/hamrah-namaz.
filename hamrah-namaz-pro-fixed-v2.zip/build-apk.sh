#!/usr/bin/env bash
# ============================================================
#  ساخت APK — همراه نماز من
#  پیش‌نیاز: JDK 17+ و Android SDK (با build-tools و platform 36)
#  این اسکریپت همه‌چیز را به‌صورت خودکار انجام می‌دهد.
# ============================================================
set -e

cd "$(dirname "$0")"

echo "==> ۱) بررسی Java"
if ! command -v java >/dev/null 2>&1; then
  echo "خطا: Java یافت نشد. JDK 17 یا بالاتر نصب کنید."
  exit 1
fi
java -version

echo "==> ۲) بررسی Android SDK"
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  # حدس‌های رایج
  for d in "$HOME/Android/Sdk" "$HOME/android-sdk" "/opt/android-sdk" "/usr/lib/android-sdk"; do
    if [ -d "$d" ]; then export ANDROID_HOME="$d"; break; fi
  done
fi
if [ -z "$ANDROID_HOME" ] || [ ! -d "$ANDROID_HOME" ]; then
  echo "خطا: ANDROID_HOME تنظیم نیست. آدرس Android SDK را در ANDROID_HOME قرار دهید."
  exit 1
fi
echo "ANDROID_HOME = $ANDROID_HOME"

echo "==> ۳) نصب وابستگی‌های node (در صورت نبود)"
[ -d node_modules ] || npm install

echo "==> ۴) build نسخه وب"
npm run build

echo "==> ۵) همگام‌سازی دارایی‌ها با اندروید"
npx cap sync android

echo "==> ۶) ساخت APK (release + امضای خودکار)"
cd android
chmod +x gradlew
./gradlew assembleRelease

echo ""
echo "============================================================"
echo "✔ APK ساخته شد:"
echo "  android/app/build/outputs/apk/release/app-release-unsigned.apk"
echo ""
echo "برای نصب روی گوشی باید امضا شود (یک‌بار، با keytool + apksigner):"
echo "  keytool -genkeypair -v -keystore mydeen.keystore -alias mydeen \\"
echo "          -keyalg RSA -keysize 2048 -validity 10000"
echo "  apksigner sign --ks mydeen.keystore --out app-release.apk \\"
echo "          app/build/outputs/apk/release/app-release-unsigned.apk"
echo "  (بعد از امضا، app-release.apk قابل نصب است)"
echo "============================================================"
