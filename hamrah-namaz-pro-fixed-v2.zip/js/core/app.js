/* ===== همراه نماز من — پوسته اپ =====
 * رندر Sidebar (دسکتاپ)، Topbar (موبایل) و BottomNav (موبایل).
 * محتوا در <main id="page"> توسط Router بارگذاری می‌شود.
 */

import { ICONS } from '../utils/helpers.js';
import Theme from './theme.js';
import i18n from './i18n.js';
import Store from './store.js';

export const NAV_ITEMS = [
  { path: '/', id: 'dashboard', icon: 'home', label: 'dashboard' },
  { path: '/prayers', id: 'prayers', icon: 'mosque', label: 'prayers' },
  { path: '/tasbih', id: 'tasbih', icon: 'beads', label: 'tasbih' },
  { path: '/dhikr', id: 'dhikr', icon: 'book', label: 'dhikr' },
  { path: '/quran', id: 'quran', icon: 'quran', label: 'quran' },
  { path: '/reports', id: 'reports', icon: 'chart', label: 'reports' },
  { path: '/goals', id: 'goals', icon: 'target', label: 'goals' },
  { path: '/learn', id: 'learn', icon: 'grad', label: 'learn' },
  { path: '/achievements', id: 'achievements', icon: 'trophy', label: 'achievements' },
  { path: '/settings', id: 'settings', icon: 'gear', label: 'settings' },
];

/* ۵ آیتم اصلی ناوبری پایین موبایل + برگه «بیشتر» */
const BOTTOM_MAIN = ['dashboard', 'prayers', 'tasbih', 'quran'];
const BOTTOM_MORE = ['dhikr', 'reports', 'goals', 'learn', 'achievements', 'settings'];

const LOGO_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4 8v2h16V8l-8-5Z"/><path d="M6 11v7m4-7v7m4-7v7m4-7v7M3 20h18"/></svg>`;

function brandHTML() {
  return `
    <div class="brand">
      <div class="logo">${LOGO_SVG}</div>
      <div>
        <h1>${i18n.t('appName')}</h1>
        <div class="subtitle">${i18n.t('tagline')}</div>
      </div>
    </div>`;
}

export const App = {
  currentPath: '/',

  renderShell() {
    const shell = document.getElementById('shell');
    if (!shell) return;
    shell.innerHTML = `
      <aside class="sidebar" id="sidebar" aria-label="ناوبری اصلی">
        ${brandHTML()}
        <div class="nav-label">بخش‌ها</div>
        <nav class="nav" id="sidebar-nav">
          ${NAV_ITEMS.map((n) => `
            <a href="${n.path}" data-nav="${n.id}">${ICONS[n.icon]}<span>${i18n.t(n.label)}</span></a>
          `).join('')}
        </nav>
        <div class="side-foot">همراه نماز من · نسخه ۱٫۰</div>
      </aside>
      <div class="main-wrap">
        <header class="topbar">
          <div class="brand">
            <div class="logo">${LOGO_SVG}</div>
            <div>
              <h1 id="topbar-title">${i18n.t('appName')}</h1>
              <div class="subtitle" id="topbar-date"></div>
            </div>
          </div>
          <div class="topbar-actions">
            <button class="icon-btn" id="theme-toggle" aria-label="تغییر حالت روشن/تاریک" title="حالت روشن/تاریک"></button>
            <a class="icon-btn" href="/settings" data-nav="settings" aria-label="تنظیمات">${ICONS.gear}</a>
          </div>
        </header>
        <main id="page"></main>
      </div>
      <nav class="bottomnav" id="bottomnav" aria-label="ناوبری پایین">
        ${BOTTOM_MAIN.map((id) => {
          const n = NAV_ITEMS.find((x) => x.id === id);
          return `<a href="${n.path}" data-nav="${id}">${ICONS[n.icon]}<span>${i18n.t(n.label)}</span></a>`;
        }).join('')}
        <button data-nav="more" id="more-btn" aria-label="بیشتر">${ICONS.more}<span>${i18n.t('more')}</span></button>
      </nav>
    `;

    // تاریخ امروز در topbar
    const dateEl = document.getElementById('topbar-date');
    if (dateEl) dateEl.textContent = i18n.formatFullDate(new Date());

    // دکمه تم
    const themeBtn = document.getElementById('theme-toggle');
    if (themeBtn) {
      const paint = () => {
        const dark = document.documentElement.getAttribute('data-theme') === 'dark';
        themeBtn.innerHTML = dark ? ICONS.sun : ICONS.moon;
      };
      paint();
      themeBtn.addEventListener('click', () => {
        Theme.toggle();
        paint();
      });
      StoreSubscribeTheme(paint);
    }

    // «بیشتر» در موبایل
    const moreBtn = document.getElementById('more-btn');
    if (moreBtn) moreBtn.addEventListener('click', () => this.openMoreSheet());

    // باز/بستن سایدبار در موبایل (با کلیک روی صفحه وقتی باز است)
    this.bindSidebarOverlay();
  },

  openMoreSheet() {
    this.closeMoreSheet();
    const backdrop = document.createElement('div');
    backdrop.className = 'sheet-backdrop';
    backdrop.id = 'sheet-backdrop';
    const sheet = document.createElement('div');
    sheet.className = 'sheet';
    sheet.id = 'more-sheet';
    const active = NAV_ITEMS.find((n) => n.path === this.currentPath);
    sheet.innerHTML = `
      <div class="sheet-handle"></div>
      <h3>${i18n.t('more')}</h3>
      <div class="sheet-grid">
        ${BOTTOM_MORE.map((id) => {
          const n = NAV_ITEMS.find((x) => x.id === id);
          const isActive = active?.id === id;
          return `<a href="${n.path}" class="${isActive ? 'active' : ''}" data-nav="${id}">${ICONS[n.icon]}<span>${i18n.t(n.label)}</span></a>`;
        }).join('')}
      </div>`;
    backdrop.addEventListener('click', () => this.closeMoreSheet());
    document.body.append(backdrop, sheet);
  },

  closeMoreSheet() {
    document.getElementById('sheet-backdrop')?.remove();
    document.getElementById('more-sheet')?.remove();
  },

  bindSidebarOverlay() {
    const page = document.getElementById('page');
    if (!page) return;
    page.addEventListener('click', (e) => {
      const link = e.target.closest('a[href^="/"]');
      if (link) {
        e.preventDefault();
        const href = link.getAttribute('href');
        this.closeMoreSheet();
        this.closeSidebar();
        if (window.__router) window.__router.navigate(href);
      }
    });
  },

  openSidebar() {
    const sb = document.getElementById('sidebar');
    if (!sb) return;
    sb.classList.add('open');
    let ov = document.getElementById('sidebar-overlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.className = 'sidebar-overlay';
      ov.id = 'sidebar-overlay';
      ov.addEventListener('click', () => this.closeSidebar());
      document.body.appendChild(ov);
    }
  },

  closeSidebar() {
    document.getElementById('sidebar')?.classList.remove('open');
    document.getElementById('sidebar-overlay')?.remove();
  },

  /** به‌روزرسانی آیتم فعال ناوبری + عنوان */
  setActive(path) {
    this.currentPath = path;
    const item = NAV_ITEMS.find((n) => n.path === path) || NAV_ITEMS[0];
    document.querySelectorAll('[data-nav]').forEach((el) => {
      el.classList.toggle('active', el.dataset.nav === item.id);
    });
    const title = document.getElementById('topbar-title');
    if (title) title.textContent = i18n.t(item.label);
    document.title = `${i18n.t(item.label)} — ${i18n.t('appName')}`;
    this.closeMoreSheet();
  }
};

/* اشتراک‌گذاری ساده برای به‌روزرسانی آیکون تم */
function StoreSubscribeTheme(paint) {
  StoreSubs.push(paint);
}
const StoreSubs = [];
export function notifyThemeChange() {
  StoreSubs.forEach((fn) => { try { fn(); } catch (e) { /* بی‌خطر */ } });
}

// ثبت تغییر تم از Store
Store.subscribe('settings', () => notifyThemeChange());
