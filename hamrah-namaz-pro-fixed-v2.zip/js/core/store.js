/* ===== همراه نماز من — Store =====
 * لایه ذخیره‌سازی محلی (offline-first) با انتشار رویداد.
 * کلیدها با پیشوند hamrah_pro: ذخیره می‌شوند.
 * لایه Supabase (js/core/supabase.js) روی همین کلیدها همگام‌سازی می‌کند.
 */

import { supabaseQueue } from './supabase.js';

const PREFIX = 'hamrah_pro:';
const listeners = new Map(); // key -> Set<fn>

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (e) {
    console.warn('[Store] خطا در خواندن کلید:', key, e);
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('[Store] خطا در نوشتن کلید:', key, e);
  }
  emit(key, value);
  // همگام‌سازی اختیاری با ابر (اگر Supabase پیکربندی شده باشد)
  supabaseQueue.enqueue(key, value);
}

function emit(key, value) {
  const set = listeners.get(key) || listeners.get('*');
  if (set) set.forEach((fn) => { try { fn(value, key); } catch (e) { console.error(e); } });
}

export const Store = {
  get(key, fallback = null) {
    return read(key, fallback);
  },

  set(key, value) {
    write(key, value);
  },

  remove(key) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch (e) { /* بی‌خطر */ }
    emit(key, null);
    supabaseQueue.enqueue(key, null);
  },

  /** تغییر یک کلید داخلی آبجکت ذخیره‌شده (merge) */
  update(key, mutator, fallback = {}) {
    const cur = read(key, fallback);
    const next = mutator(cur);
    write(key, next);
    return next;
  },

  subscribe(key, fn) {
    if (!listeners.has(key)) listeners.set(key, new Set());
    listeners.get(key).add(fn);
    return () => listeners.get(key)?.delete(fn);
  },

  /** همه کلیدهای کاربر (برای پشتیبان‌گیری) */
  allKeys() {
    try {
      return Object.keys(localStorage)
        .filter((k) => k.startsWith(PREFIX))
        .map((k) => k.slice(PREFIX.length));
    } catch (e) {
      return [];
    }
  },

  /** خروجی کامل (backup JSON) */
  exportAll() {
    const out = { app: 'hamrah-namaz', version: 1, exportedAt: new Date().toISOString(), data: {} };
    this.allKeys().forEach((k) => {
      const raw = localStorage.getItem(PREFIX + k);
      if (raw !== null) {
        try { out.data[k] = JSON.parse(raw); } catch (e) { /* رد */ }
      }
    });
    return out;
  },

  /** بازیابی از backup JSON — با اعتبارسنجی ساختار */
  importAll(obj) {
    if (!obj || typeof obj !== 'object' || obj.app !== 'hamrah-namaz' || !obj.data || typeof obj.data !== 'object') {
      throw new Error('ساختار فایل پشتیبان نامعتبر است');
    }
    let count = 0;
    Object.entries(obj.data).forEach(([k, v]) => {
      // جلوگیری از کلیدهای غیرمنتظره (فقط کلیدهای شناخته‌شده)
      if (/^[a-zA-Z0-9:_-]+$/.test(k)) {
        localStorage.setItem(PREFIX + k, JSON.stringify(v));
        count++;
      }
    });
    return count;
  },

  /** پاک‌سازی کامل داده‌های کاربر */
  clearAll() {
    this.allKeys().forEach((k) => {
      try { localStorage.removeItem(PREFIX + k); } catch (e) { /* بی‌خطر */ }
    });
    supabaseQueue.clear();
  },

  init() {
    // هیچ کاری لازم نیست؛ فقط نقطه شروع برای آینده
  }
};

export default Store;
