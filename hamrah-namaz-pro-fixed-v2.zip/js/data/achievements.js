/* ===== همراه نماز من — نشان‌ها و دستاوردها =====
 * فقط تشویقی؛ هیچ قضاوتی درباره ایمان کاربر نمی‌کنند.
 * progress: { current, target } — برای نمایش پیشرفت
 */

export const ACHIEVEMENTS = [
  {
    id: 'first_prayer', icon: 'check', name: 'نخستین قدم',
    desc: 'اولین نماز خود را ثبت کردی',
    check: (s) => s.totalPrayers >= 1,
    progress: (s) => ({ current: Math.min(s.totalPrayers, 1), target: 1 })
  },
  {
    id: 'full_day', icon: 'mosque', name: 'روز کامل',
    desc: 'هر پنج نماز یک روز را ثبت کردی',
    check: (s) => s.bestDay >= 5,
    progress: (s) => ({ current: Math.min(s.bestDay, 5), target: 5 })
  },
  {
    id: 'week_streak', icon: 'flame', name: 'هفته پابرجا',
    desc: '۷ روز پیاپی هر ۵ نماز را ثبت کردی',
    check: (s) => s.streak >= 7,
    progress: (s) => ({ current: Math.min(s.streak, 7), target: 7 })
  },
  {
    id: 'month_streak', icon: 'flame', name: 'ماه پابرجا',
    desc: '۳۰ روز پیاپی هر ۵ نماز را ثبت کردی',
    check: (s) => s.streak >= 30,
    progress: (s) => ({ current: Math.min(s.streak, 30), target: 30 })
  },
  {
    id: 'qada_care', icon: 'heart', name: 'مراقب نماز',
    desc: 'اولین نماز قضا را جبران و ثبت کردی',
    check: (s) => s.totalQada >= 1,
    progress: (s) => ({ current: Math.min(s.totalQada, 1), target: 1 })
  },
  {
    id: 'tasbih_100', icon: 'beads', name: 'تسبیح‌گوی',
    desc: 'در مجموع ۱۰۰ تسبیح ثبت کردی',
    check: (s) => s.totalTasbih >= 100,
    progress: (s) => ({ current: Math.min(s.totalTasbih, 100), target: 100 })
  },
  {
    id: 'tasbih_1000', icon: 'beads', name: 'صد هزار ذکر',
    desc: 'در مجموع ۱۰۰۰ تسبیح ثبت کردی',
    check: (s) => s.totalTasbih >= 1000,
    progress: (s) => ({ current: Math.min(s.totalTasbih, 1000), target: 1000 })
  },
  {
    id: 'tasbih_10000', icon: 'sparkle', name: 'ذکرگویی پُرسوز',
    desc: 'در مجموع ۱۰٬۰۰۰ تسبیح ثبت کردی',
    check: (s) => s.totalTasbih >= 10000,
    progress: (s) => ({ current: Math.min(s.totalTasbih, 10000), target: 10000 })
  },
  {
    id: 'quran_1', icon: 'quran', name: 'آغازین قرآن',
    desc: 'اولین سوره را مطالعه کردی',
    check: (s) => s.readSurahs >= 1,
    progress: (s) => ({ current: Math.min(s.readSurahs, 1), target: 1 })
  },
  {
    id: 'quran_10', icon: 'quran', name: 'ده سوره‌ای',
    desc: '۱۰ سوره را مطالعه کردی',
    check: (s) => s.readSurahs >= 10,
    progress: (s) => ({ current: Math.min(s.readSurahs, 10), target: 10 })
  },
  {
    id: 'quran_30', icon: 'trophy', name: 'سی‌سوره‌ای',
    desc: '۳۰ سوره را مطالعه کردی',
    check: (s) => s.readSurahs >= 30,
    progress: (s) => ({ current: Math.min(s.readSurahs, 30), target: 30 })
  },
  {
    id: 'learn_5', icon: 'grad', name: 'دانشجو دین',
    desc: '۵ درس آموزشی را خواندی',
    check: (s) => s.learnedLessons >= 5,
    progress: (s) => ({ current: Math.min(s.learnedLessons, 5), target: 5 })
  },
  {
    id: 'learn_20', icon: 'grad', name: 'پژوهشگر',
    desc: '۲۰ درس آموزشی را خواندی',
    check: (s) => s.learnedLessons >= 20,
    progress: (s) => ({ current: Math.min(s.learnedLessons, 20), target: 20 })
  },
  {
    id: 'goal_done', icon: 'target', name: 'هدف‌آور',
    desc: 'اولین هدف شخصی‌ات را کامل کردی',
    check: (s) => s.completedGoals >= 1,
    progress: (s) => ({ current: Math.min(s.completedGoals, 1), target: 1 })
  },
  {
    id: 'dhikr_fav', icon: 'heart', name: 'ذکرهای دلخواه',
    desc: '۵ ذکر را به علاقه‌مندی‌ها اضافه کردی',
    check: (s) => s.favDhikr >= 5,
    progress: (s) => ({ current: Math.min(s.favDhikr, 5), target: 5 })
  },
  {
    id: 'note_writer', icon: 'note', name: 'روزی‌نویس',
    desc: '۵ یادداشت روزانه درباره نماز نوشتی',
    check: (s) => s.totalNotes >= 5,
    progress: (s) => ({ current: Math.min(s.totalNotes, 5), target: 5 })
  }
];

/**
 * محاسبه آمار کلی از داده‌های واقعی Store
 */
export function computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate }) {
  const PRAYER_KEYS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];

  let totalPrayers = 0, totalQada = 0, totalNotes = 0, bestDay = 0;
  let streak = 0;
  let offset = 0;
  const t = Store.get('day:' + todayKey(), {});
  let tDone = 0;
  PRAYER_KEYS.forEach((k) => { if (t[k]?.done) tDone++; });
  if (tDone < 5) offset = 1;

  for (let i = 0; i < 400; i++) {
    const key = daysAgoKey(i);
    const d = Store.get('day:' + key, {});
    let done = 0;
    PRAYER_KEYS.forEach((k) => { if (d[k]?.done) done++; });
    totalPrayers += done;
    bestDay = Math.max(bestDay, done);
    if (Array.isArray(d.qada)) totalQada += d.qada.filter((q) => q.done).length;
    if (d.note && d.note.trim()) totalNotes++;
    // زنجیره
    if (i >= offset && i < 3660) {
      if (done >= 5) streak++;
      else break;
    }
  }

  // تسبیحات
  const tasbih = Store.get('tasbih', { history: [] });
  const totalTasbih = (tasbih.history || []).reduce((s, h) => s + (h.count || 0), 0);

  // قرآن
  const quran = Store.get('quran', { readSurahs: [] });
  const readSurahs = (quran.readSurahs || []).length;

  // آموزش
  const learn = Store.get('learn', { completed: [] });
  const learnedLessons = (learn.completed || []).length;

  // اهداف
  const goals = Store.get('goals', []);
  const completedGoals = (goals || []).filter((g) => g.completed).length;

  // علاقه‌مندی‌ها
  const favDhikr = (Store.get('adhkar_favs', []) || []).length;

  return {
    totalPrayers, totalQada, totalNotes, bestDay, streak,
    totalTasbih, readSurahs, learnedLessons, completedGoals, favDhikr
  };
}

/**
 * بررسی و قفل‌گشایی نشان‌ها (بازگشت لیست نشان‌های تازه‌گشوده)
 */
export function checkAchievements(Store, stats) {
  const unlocked = Store.get('achievements', {});
  const newly = [];
  ACHIEVEMENTS.forEach((a) => {
    if (!unlocked[a.id] && a.check(stats)) {
      unlocked[a.id] = new Date().toISOString();
      newly.push(a.id);
    }
  });
  if (newly.length) Store.set('achievements', unlocked);
  return newly;
}

export default ACHIEVEMENTS;
