/* ===== همراه نماز من — فهرست ۱۱۴ سوره =====
 * نام‌ها و تعداد آیات از متن معتبر قرآن.
 * متن آیات و ترجمه از API عمومی quran.com (منبع: mushaf حفص + ترجمه غهارشادی) بارگذاری می‌شود.
 */

export const SURAHS = [
  { n: 1, ar: 'الفاتحة', fa: 'سوره حمد', ayahs: 7, place: 'مکّی' },
  { n: 2, ar: 'البقرة', fa: 'سوره بقره', ayahs: 286, place: 'مدنی' },
  { n: 3, ar: 'آل عمران', fa: 'سوره آل عمران', ayahs: 200, place: 'مدنی' },
  { n: 4, ar: 'النساء', fa: 'سوره نساء', ayahs: 176, place: 'مدنی' },
  { n: 5, ar: 'المائدة', fa: 'سوره مائده', ayahs: 120, place: 'مدنی' },
  { n: 6, ar: 'الأنعام', fa: 'سوره انعام', ayahs: 165, place: 'مکّی' },
  { n: 7, ar: 'الأعراف', fa: 'سوره اعراف', ayahs: 206, place: 'مکّی' },
  { n: 8, ar: 'الأنفال', fa: 'سوره انفال', ayahs: 75, place: 'مدنی' },
  { n: 9, ar: 'التوبة', fa: 'سوره توبه', ayahs: 129, place: 'مدنی' },
  { n: 10, ar: 'يونس', fa: 'سوره یونس', ayahs: 109, place: 'مکّی' },
  { n: 11, ar: 'هود', fa: 'سوره هود', ayahs: 123, place: 'مکّی' },
  { n: 12, ar: 'يوسف', fa: 'سوره یوسف', ayahs: 111, place: 'مکّی' },
  { n: 13, ar: 'الرعد', fa: 'سوره رعد', ayahs: 43, place: 'مدنی' },
  { n: 14, ar: 'إبراهيم', fa: 'سوره ابراهیم', ayahs: 52, place: 'مکّی' },
  { n: 15, ar: 'الحجر', fa: 'سوره حجر', ayahs: 99, place: 'مکّی' },
  { n: 16, ar: 'النحل', fa: 'سوره نحل', ayahs: 128, place: 'مکّی' },
  { n: 17, ar: 'الإسراء', fa: 'سوره اسراء', ayahs: 111, place: 'مکّی' },
  { n: 18, ar: 'الكهف', fa: 'سوره کهف', ayahs: 110, place: 'مکّی' },
  { n: 19, ar: 'مريم', fa: 'سوره مریم', ayahs: 98, place: 'مکّی' },
  { n: 20, ar: 'طه', fa: 'سوره طه', ayahs: 135, place: 'مکّی' },
  { n: 21, ar: 'الأنبياء', fa: 'سوره انبیاء', ayahs: 112, place: 'مکّی' },
  { n: 22, ar: 'الحج', fa: 'سوره حج', ayahs: 78, place: 'مدنی' },
  { n: 23, ar: 'المؤمنون', fa: 'سوره مؤمنون', ayahs: 118, place: 'مکّی' },
  { n: 24, ar: 'النور', fa: 'سوره نور', ayahs: 64, place: 'مدنی' },
  { n: 25, ar: 'الفرقان', fa: 'سوره فرقان', ayahs: 77, place: 'مکّی' },
  { n: 26, ar: 'الشعراء', fa: 'سوره شعراء', ayahs: 227, place: 'مکّی' },
  { n: 27, ar: 'النمل', fa: 'سوره نمل', ayahs: 93, place: 'مکّی' },
  { n: 28, ar: 'القصص', fa: 'سوره قصص', ayahs: 88, place: 'مکّی' },
  { n: 29, ar: 'العنكبوت', fa: 'سوره عنکبوت', ayahs: 69, place: 'مکّی' },
  { n: 30, ar: 'الروم', fa: 'سوره روم', ayahs: 60, place: 'مکّی' },
  { n: 31, ar: 'لقمان', fa: 'سوره لقمان', ayahs: 34, place: 'مکّی' },
  { n: 32, ar: 'السجدة', fa: 'سوره سجده', ayahs: 30, place: 'مکّی' },
  { n: 33, ar: 'الأحزاب', fa: 'سوره احزاب', ayahs: 73, place: 'مدنی' },
  { n: 34, ar: 'سبأ', fa: 'سوره سبأ', ayahs: 54, place: 'مکّی' },
  { n: 35, ar: 'فاطر', fa: 'سوره فاطر', ayahs: 45, place: 'مکّی' },
  { n: 36, ar: 'يس', fa: 'سوره یس', ayahs: 83, place: 'مکّی' },
  { n: 37, ar: 'الصافات', fa: 'سوره صافات', ayahs: 182, place: 'مکّی' },
  { n: 38, ar: 'ص', fa: 'سوره ص', ayahs: 88, place: 'مکّی' },
  { n: 39, ar: 'الزمر', fa: 'سوره زمر', ayahs: 75, place: 'مکّی' },
  { n: 40, ar: 'غافر', fa: 'سوره غافر', ayahs: 85, place: 'مکّی' },
  { n: 41, ar: 'فصلت', fa: 'سوره فصلت', ayahs: 54, place: 'مکّی' },
  { n: 42, ar: 'الشورى', fa: 'سوره شوری', ayahs: 53, place: 'مکّی' },
  { n: 43, ar: 'الزخرف', fa: 'سوره زخرف', ayahs: 89, place: 'مکّی' },
  { n: 44, ar: 'الدخان', fa: 'سوره دخان', ayahs: 59, place: 'مکّی' },
  { n: 45, ar: 'الجاثية', fa: 'سوره جاثیه', ayahs: 37, place: 'مکّی' },
  { n: 46, ar: 'الأحقاف', fa: 'سوره احقاف', ayahs: 35, place: 'مکّی' },
  { n: 47, ar: 'محمد', fa: 'سوره محمد', ayahs: 38, place: 'مدنی' },
  { n: 48, ar: 'الفتح', fa: 'سوره فتح', ayahs: 29, place: 'مدنی' },
  { n: 49, ar: 'الحجرات', fa: 'سوره حجرات', ayahs: 18, place: 'مدنی' },
  { n: 50, ar: 'ق', fa: 'سوره قاف', ayahs: 45, place: 'مکّی' },
  { n: 51, ar: 'الذاريات', fa: 'سوره ذاریات', ayahs: 60, place: 'مکّی' },
  { n: 52, ar: 'الطور', fa: 'سوره طور', ayahs: 49, place: 'مکّی' },
  { n: 53, ar: 'النجم', fa: 'سوره نجم', ayahs: 62, place: 'مکّی' },
  { n: 54, ar: 'القمر', fa: 'سوره قمر', ayahs: 55, place: 'مکّی' },
  { n: 55, ar: 'الرحمن', fa: 'سوره رحمان', ayahs: 78, place: 'مدنی' },
  { n: 56, ar: 'الواقعة', fa: 'سوره واقعه', ayahs: 96, place: 'مکّی' },
  { n: 57, ar: 'الحديد', fa: 'سوره حديد', ayahs: 29, place: 'مدنی' },
  { n: 58, ar: 'المجادلة', fa: 'سوره مجادله', ayahs: 22, place: 'مدنی' },
  { n: 59, ar: 'الحشر', fa: 'سوره حشر', ayahs: 24, place: 'مدنی' },
  { n: 60, ar: 'الممتحنة', fa: 'سوره ممتحنه', ayahs: 13, place: 'مدنی' },
  { n: 61, ar: 'الصف', fa: 'سوره صف', ayahs: 14, place: 'مدنی' },
  { n: 62, ar: 'الجمعة', fa: 'سوره جمعه', ayahs: 11, place: 'مدنی' },
  { n: 63, ar: 'المنافقون', fa: 'سوره منافقون', ayahs: 11, place: 'مدنی' },
  { n: 64, ar: 'التغابن', fa: 'سوره تغابن', ayahs: 18, place: 'مدنی' },
  { n: 65, ar: 'الطلاق', fa: 'سوره طلاق', ayahs: 12, place: 'مدنی' },
  { n: 66, ar: 'التحريم', fa: 'سوره تحریم', ayahs: 12, place: 'مدنی' },
  { n: 67, ar: 'الملك', fa: 'سوره ملک', ayahs: 30, place: 'مکّی' },
  { n: 68, ar: 'القلم', fa: 'سوره قلم', ayahs: 52, place: 'مکّی' },
  { n: 69, ar: 'الحاقة', fa: 'سوره حاقه', ayahs: 52, place: 'مکّی' },
  { n: 70, ar: 'المعارج', fa: 'سوره معارج', ayahs: 44, place: 'مکّی' },
  { n: 71, ar: 'نوح', fa: 'سوره نوح', ayahs: 28, place: 'مکّی' },
  { n: 72, ar: 'الجن', fa: 'سوره جن', ayahs: 28, place: 'مکّی' },
  { n: 73, ar: 'المزمل', fa: 'سوره مزمل', ayahs: 20, place: 'مکّی' },
  { n: 74, ar: 'المدثر', fa: 'سوره مدثر', ayahs: 56, place: 'مکّی' },
  { n: 75, ar: 'القيامة', fa: 'سوره قیامه', ayahs: 40, place: 'مکّی' },
  { n: 76, ar: 'الانسان', fa: 'سوره انسان', ayahs: 31, place: 'مدنی' },
  { n: 77, ar: 'المرسلات', fa: 'سوره مرسلات', ayahs: 50, place: 'مکّی' },
  { n: 78, ar: 'النبأ', fa: 'سوره نبأ', ayahs: 40, place: 'مکّی' },
  { n: 79, ar: 'النازعات', fa: 'سوره نازعات', ayahs: 46, place: 'مکّی' },
  { n: 80, ar: 'عبس', fa: 'سوره عبس', ayahs: 42, place: 'مکّی' },
  { n: 81, ar: 'التكوير', fa: 'سوره تکویر', ayahs: 29, place: 'مکّی' },
  { n: 82, ar: 'الانفطار', fa: 'سوره انفطار', ayahs: 19, place: 'مکّی' },
  { n: 83, ar: 'المطففين', fa: 'سوره مطففین', ayahs: 36, place: 'مکّی' },
  { n: 84, ar: 'الانشقاق', fa: 'سوره انشقاق', ayahs: 25, place: 'مکّی' },
  { n: 85, ar: 'البروج', fa: 'سوره بروج', ayahs: 22, place: 'مکّی' },
  { n: 86, ar: 'الطارق', fa: 'سوره طارق', ayahs: 17, place: 'مکّی' },
  { n: 87, ar: 'الأعلى', fa: 'سوره أعلى', ayahs: 19, place: 'مکّی' },
  { n: 88, ar: 'الغاشية', fa: 'سوره غاشیه', ayahs: 26, place: 'مکّی' },
  { n: 89, ar: 'الفجر', fa: 'سوره فجر', ayahs: 30, place: 'مکّی' },
  { n: 90, ar: 'البلد', fa: 'سوره بلد', ayahs: 20, place: 'مکّی' },
  { n: 91, ar: 'الشمس', fa: 'سوره شمس', ayahs: 15, place: 'مکّی' },
  { n: 92, ar: 'الليل', fa: 'سوره لیل', ayahs: 21, place: 'مکّی' },
  { n: 93, ar: 'الضحى', fa: 'سوره ضحی', ayahs: 11, place: 'مکّی' },
  { n: 94, ar: 'الشرح', fa: 'سوره شرح', ayahs: 8, place: 'مکّی' },
  { n: 95, ar: 'التين', fa: 'سوره تین', ayahs: 8, place: 'مکّی' },
  { n: 96, ar: 'العلق', fa: 'سوره علق', ayahs: 19, place: 'مکّی' },
  { n: 97, ar: 'القدر', fa: 'سوره قدر', ayahs: 5, place: 'مکّی' },
  { n: 98, ar: 'البينة', fa: 'سوره بیّنه', ayahs: 8, place: 'مدنی' },
  { n: 99, ar: 'الزلزلة', fa: 'سوره زلزله', ayahs: 8, place: 'مدنی' },
  { n: 100, ar: 'العاديات', fa: 'سوره عادیات', ayahs: 11, place: 'مکّی' },
  { n: 101, ar: 'القارعة', fa: 'سوره قارعه', ayahs: 11, place: 'مکّی' },
  { n: 102, ar: 'التكاثر', fa: 'سوره تکاثر', ayahs: 8, place: 'مکّی' },
  { n: 103, ar: 'العصر', fa: 'سوره عصر', ayahs: 3, place: 'مکّی' },
  { n: 104, ar: 'الهمزة', fa: 'سوره همزه', ayahs: 9, place: 'مکّی' },
  { n: 105, ar: 'الفيل', fa: 'سوره فیل', ayahs: 5, place: 'مکّی' },
  { n: 106, ar: 'قريش', fa: 'سوره قریش', ayahs: 4, place: 'مکّی' },
  { n: 107, ar: 'الماعون', fa: 'سوره ماعون', ayahs: 7, place: 'مکّی' },
  { n: 108, ar: 'الكوثر', fa: 'سوره کوثر', ayahs: 3, place: 'مکّی' },
  { n: 109, ar: 'الكافرون', fa: 'سوره کافرون', ayahs: 6, place: 'مکّی' },
  { n: 110, ar: 'النصر', fa: 'سوره نصر', ayahs: 3, place: 'مدنی' },
  { n: 111, ar: 'المسد', fa: 'سوره مسد', ayahs: 5, place: 'مکّی' },
  { n: 112, ar: 'الإخلاص', fa: 'سوره اخلاص', ayahs: 4, place: 'مکّی' },
  { n: 113, ar: 'الفلق', fa: 'سوره فلق', ayahs: 5, place: 'مکّی' },
  { n: 114, ar: 'الناس', fa: 'سوره ناس', ayahs: 6, place: 'مکّی' }
];

/* ---------- API قرآن (quran.com — بدون کلید) ---------- */
const API = 'https://api.quran.com/api/v4';

/** بارگذاری متن عربی + ترجمه فارسی یک سوره (با کش محلی) */
export async function fetchSurah(n) {
  const cacheKey = 'quran:surah:' + n;
  const cached = StoreGet(cacheKey);
  if (cached) return cached;

  const [arRes, trRes] = await Promise.all([
    fetch(`${API}/quran/verses/ar-mushaf?chapter_number=${n}`).then((r) => r.json()),
    fetch(`${API}/quran/verses/fa-ghohar?chapter_number=${n}`).then((r) => r.json()),
  ]);

  const verses = (arRes.verses || []).map((v, i) => {
    const tr = (trRes.verses || [])[i];
    return {
      ayah: v.ayah_number,
      ar: v.text,
      tr: tr ? tr.text : ''
    };
  });

  const data = { n, verses, fetchedAt: Date.now() };
  StoreSet(cacheKey, data);
  return data;
}

function StoreGet(key) {
  try {
    const raw = localStorage.getItem('hamrah_pro:' + key);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

function StoreSet(key, value) {
  try {
    localStorage.setItem('hamrah_pro:' + key, JSON.stringify(value));
  } catch (e) { /* حافظه پر */ }
}
