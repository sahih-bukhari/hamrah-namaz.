/* ===== صفحه برنامه‌ریزی عبادت =====
 * - ایجاد هدف با عنوان، دسته، فرکانس و هدف عددی
 * - ثبت پیشرفت روزانه
 * - نمایش زنجیره و درصد تکمیل
 * - اهداف تکمیل‌شده / باقی‌مانده
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, faNumBig, todayKey, toast, confirmDialog, uid, validText, validInt, validTime, openModal } from '../js/utils/helpers.js';

const CATEGORIES = [
  { id: 'quran', name: 'قرآن', icon: 'quran' },
  { id: 'dhikr', name: 'ذکر', icon: 'beads' },
  { id: 'hadith', name: 'حدیث', icon: 'book' },
  { id: 'memorize', name: 'حفظ', icon: 'sparkle' },
  { id: 'study', name: 'مطالعه', icon: 'grad' },
  { id: 'other', name: 'سایر', icon: 'target' }
];

const FREQUENCIES = [
  { id: 'daily', name: 'روزانه' },
  { id: 'weekly', name: 'هفتگی' }
];

export default {
  render(root) {
    this.root = root;
    this.goals = Store.get('goals', []);
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const tk = todayKey();
    const active = this.goals.filter((g) => !g.completed);
    const completed = this.goals.filter((g) => g.completed);

    root.innerHTML = `
      <div class="actions" style="margin-bottom:14px">
        <button class="btn btn-primary" id="goal-add">${ICONS.plus} هدف جدید</button>
      </div>

      <div class="settings-section">اهداف فعال (${faNum(active.length)})</div>
      ${active.length === 0
        ? `<div class="card"><div class="empty">${ICONS.target}<p>هنوز هدفی ثبت نکرده‌ای</p><p class="muted" style="font-size:.75rem">مثلا: روزانه ۱۰ دقیقه قرآن بخوانم</p></div></div>`
        : active.map((g) => this.goalCard(g, tk)).join('')}

      ${completed.length ? `
        <div class="settings-section">اهداف تکمیل‌شده (${faNum(completed.length)})</div>
        ${completed.map((g) => this.goalCard(g, tk, true)).join('')}
      ` : ''}
    `;

    this.bind();
  },

  goalCard(g, tk, isCompleted = false) {
    const cat = CATEGORIES.find((c) => c.id === g.category) || CATEGORIES[5];
    const freq = FREQUENCIES.find((f) => f.id === g.frequency) || FREQUENCIES[0];
    const doneToday = (g.doneDates || []).includes(tk);

    // پیشرفت
    let pct = 0;
    if (g.frequency === 'daily') {
      // تعداد روزهای انجام‌شده از زمان ساخت تا امروز
      const days = this.daysSince(g.createdAt);
      pct = days > 0 ? Math.min(Math.round(((g.doneDates || []).length / days) * 100), 100) : 0;
    } else {
      const weeks = Math.max(1, Math.ceil(this.daysSince(g.createdAt) / 7));
      pct = Math.min(Math.round(((g.doneDates || []).length / weeks) * 100), 100);
    }
    if (isCompleted) pct = 100;

    // زنجیره
    const streak = this.goalStreak(g);

    return `
      <div class="goal-card ${isCompleted ? 'completed' : ''}" data-id="${g.id}">
        <div class="goal-top">
          <div class="prayer-icon" style="width:38px;height:38px;border-radius:12px;background:var(--pale);color:var(--deep);display:grid;place-items:center;flex:none">${ICONS[cat.icon]}</div>
          <div class="g-title">
            ${g.title}
            <span class="g-sub">${cat.name} · ${freq.name}${g.target ? ' · هدف: ' + faNum(g.target) : ''}${g.reminderTime ? ' · ⏰ ' + faNum(g.reminderTime) : ''}</span>
          </div>
        </div>
        <div class="goal-progress">
          <div class="bar"><i style="width:${pct}%"></i></div>
          <span class="g-pct">${faNum(pct)}٪</span>
        </div>
        ${streak > 1 ? `<div class="goal-streak" style="margin-top:8px">${ICONS.flame} زنجیره ${faNum(streak)} روزه</div>` : ''}
        <div class="goal-actions">
          ${isCompleted ? '' : `
            <button class="btn ${doneToday ? 'btn-soft' : 'btn-primary'} btn-sm" data-act="toggle">${doneToday ? ICONS.check + ' امروز انجام شد' : ICONS.check + ' ثبت انجام امروز'}</button>
            <button class="btn btn-ghost btn-sm" data-act="edit">${ICONS.edit} ویرایش</button>
            <button class="btn btn-ghost btn-sm" data-act="complete">${ICONS.trophy} تکمیل</button>
            <button class="btn btn-ghost btn-sm" data-act="delete">${ICONS.trash}</button>
          `}
        </div>
      </div>`;
  },

  daysSince(iso) {
    const d = new Date(iso);
    const now = new Date();
    const ms = now - new Date(d.getFullYear(), d.getMonth(), d.getDate());
    return Math.max(1, Math.floor(ms / 86400000) + 1);
  },

  goalStreak(g) {
    const dates = new Set(g.doneDates || []);
    let n = 0;
    for (let i = 0; i < 3660; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      if (dates.has(k)) n++;
      else if (i === 0) continue; // امروز هنوز نشده، از دیروز ادامه بده
      else break;
    }
    return n;
  },

  bind() {
    const root = this.root;

    root.querySelector('#goal-add').addEventListener('click', () => this.editGoal(null));

    root.querySelectorAll('.goal-card').forEach((el) => {
      const id = el.dataset.id;
      const g = this.goals.find((x) => x.id === id);

      el.querySelector('[data-act="toggle"]')?.addEventListener('click', () => {
        const tk = todayKey();
        const i = (g.doneDates || []).indexOf(tk);
        if (i >= 0) g.doneDates.splice(i, 1);
        else g.doneDates.push(tk);
        this.save();
        this.renderView();
        this.checkAchievements();
      });

      el.querySelector('[data-act="edit"]')?.addEventListener('click', () => this.editGoal(g));

      el.querySelector('[data-act="complete"]')?.addEventListener('click', async () => {
        const ok = await confirmDialog(`هدف «${g.title}» به‌عنوان تکمیل‌شده علامت بخورد؟`, { okLabel: 'تکمیل' });
        if (!ok) return;
        g.completed = true;
        g.completedAt = new Date().toISOString();
        this.save();
        this.renderView();
        toast('🎉 هدف تکمیل شد!');
        this.checkAchievements();
      });

      el.querySelector('[data-act="delete"]')?.addEventListener('click', async () => {
        const ok = await confirmDialog(`هدف «${g.title}» حذف شود؟`, { okLabel: 'حذف', danger: true });
        if (!ok) return;
        this.goals = this.goals.filter((x) => x.id !== id);
        this.save();
        this.renderView();
      });
    });
  },

  editGoal(g) {
    const isEdit = !!g;
    const title = document.createElement('input');
    title.type = 'text';
    title.className = 'input';
    title.maxLength = 100;
    title.placeholder = 'مثلا: روزانه ۱۰ دقیقه قرآن بخوانم';
    title.value = g?.title || '';

    const cat = document.createElement('select');
    cat.className = 'select';
    cat.innerHTML = CATEGORIES.map((c) => `<option value="${c.id}" ${g?.category === c.id ? 'selected' : ''}>${c.name}</option>`).join('');

    const freq = document.createElement('select');
    freq.className = 'select';
    freq.innerHTML = FREQUENCIES.map((f) => `<option value="${f.id}" ${g?.frequency === f.id ? 'selected' : ''}>${f.name}</option>`).join('');

    const target = document.createElement('input');
    target.type = 'number';
    target.className = 'input';
    target.min = '0';
    target.max = '100000';
    target.placeholder = 'اختیاری — مثلا ۱۰ (دقیقه) یا ۵ (آیه)';
    target.value = g?.target || '';

    const reminder = document.createElement('input');
    reminder.type = 'time';
    reminder.className = 'input';
    reminder.value = g?.reminderTime || '';

    const err = document.createElement('div');
    err.className = 'field-error';

    const form = document.createElement('div');
    form.innerHTML = `
      <div class="field"><label>عنوان هدف *</label></div>
      <div class="field"><label>دسته</label></div>
      <div class="field"><label>زمان‌بندی</label></div>
      <div class="field"><label>مقدار هدف (اختیاری)</label><div class="hint">مثلا ۱۰ دقیقه قرآن، ۳۳ ذکر، ۱ حدیث</div></div>
      <div class="field"><label>یادآوری (اختیاری)</label><div class="hint">ساعت یادآوری — فقط در صورت باز بودن اپ</div></div>
    `;
    const fields = form.querySelectorAll('.field');
    fields[0].append(title);
    fields[1].append(cat);
    fields[2].append(freq);
    fields[3].append(target);
    fields[4].append(reminder);
    form.append(err);

    openModal({
      title: isEdit ? 'ویرایش هدف' : 'هدف جدید',
      body: form,
      actions: [
        {
          label: 'ذخیره', cls: 'btn-primary',
          onClick: () => {
            const t = title.value.trim();
            if (!validText(t, 100)) {
              err.textContent = 'عنوان هدف را وارد کن (حداقل ۲ حرف)';
              title.classList.add('invalid');
              return false;
            }
            const tv = target.value === '' ? 0 : parseInt(target.value, 10);
            if (tv !== 0 && !validInt(tv, 1, 100000)) {
              err.textContent = 'مقدار هدف باید عدد مثبت باشد';
              target.classList.add('invalid');
              return false;
            }
            const rt = reminder.value || '';
            if (rt && !validTime(rt)) {
              err.textContent = 'ساعت یادآوری نامعتبر است';
              reminder.classList.add('invalid');
              return false;
            }
            const data = {
              title: t,
              category: cat.value,
              frequency: freq.value,
              target: tv,
              reminderTime: rt,
              doneDates: g?.doneDates || [],
              createdAt: g?.createdAt || new Date().toISOString(),
              completed: g?.completed || false
            };
            if (isEdit) {
              Object.assign(g, data);
            } else {
              this.goals.unshift({ id: uid(), ...data });
            }
            this.save();
            this.renderView();
            toast(i18n.t('saved'));
            return true;
          }
        },
        { label: 'انصراف', cls: 'btn-ghost' }
      ]
    });
  },

  save() {
    Store.set('goals', this.goals);
  },

  checkAchievements() {
    import('../js/data/achievements.js').then(({ computeStats, checkAchievements }) => {
      import('../js/utils/helpers.js').then(({ dayKey, daysAgoKey, todayKey, keyToDate }) => {
        const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
        const newly = checkAchievements(Store, stats);
        if (newly.length) toast('🏆 نشان جدید گرفتی!');
      });
    });
  }
};
