/* ===== صفحه نمازها — پیگیری پیشرفته =====
 * - انتخاب روز (پیش/بعد)
 * - ثبت ادا با خشوع اختیاری
 * - ثبت نمازهای قضا (جدا از ادا)
 * - یادداشت روزانه
 * - تقویم ماهانه
 * - تاریخچه کامل
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, dayKey, keyToDate, todayKey, toast, confirmDialog, DOW, MONTHS_G, gregorianToJalali, jalaliToGregorian, jalaaliMonthLength, formatJalali, isLeapJalaali } from '../js/utils/helpers.js';
import { checkAchievements, computeStats } from '../js/data/achievements.js';
import { daysAgoKey } from '../js/utils/helpers.js';

const PRAYERS = [
  { key: 'fajr', name: 'نماز صبح', ar: 'صلاة الفجر', icon: 'sunrise', rakah: '۲ رکعت' },
  { key: 'dhuhr', name: 'نماز ظهر', ar: 'صلاة الظهر', icon: 'sun', rakah: '۴ رکعت' },
  { key: 'asr', name: 'نماز عصر', ar: 'صلاة العصر', icon: 'sunset', rakah: '۴ رکعت' },
  { key: 'maghrib', name: 'نماز مغرب', ar: 'صلاة المغرب', icon: 'dusk', rakah: '۳ رکعت' },
  { key: 'isha', name: 'نماز عشاء', ar: 'صلاة العشاء', icon: 'moon', rakah: '۴ رکعت' }
];

function getDay(k) { return Store.get('day:' + k, {}); }

export default {
  state: { dateKey: todayKey(), view: 'today' },

  render(root) {
    this.root = root;
    this.renderView();
  },

  renderView() {
    const root = this.root;
    const dk = this.state.dateKey;
    const d = getDay(dk);
    const isToday = dk === todayKey();
    const date = keyToDate(dk);

    let done = 0;
    PRAYERS.forEach((p) => {
      if (d[p.key]?.done) done++;
    });
    const qadaList = Array.isArray(d.qada) ? d.qada : [];
    const qadaDone = qadaList.filter((q) => q.done).length;

    const label = isToday ? i18n.t('today') : formatJalali(dk);

    root.innerHTML = `
      <!-- انتخاب روز -->
      <div class="day-selector" style="margin-bottom:14px">
        <button class="icon-btn" id="day-prev" aria-label="روز قبل">${ICONS.next}</button>
        <div class="day-label" id="day-label">${label}</div>
        <button class="icon-btn" id="day-next" ${isToday ? 'disabled' : ''} aria-label="روز بعد">${ICONS.back}</button>
        ${!isToday ? `<button class="btn btn-soft btn-sm" id="day-today">امروز</button>` : ''}
      </div>

      <!-- آمار روز -->
      <div class="stats" style="margin-bottom:14px">
        <div class="stat"><b>${faNum(done)}</b><span>ادا</span></div>
        <div class="stat gold"><b>${faNum(qadaDone)}</b><span>قضا جبران‌شده</span></div>
      </div>

      <!-- ادا -->
      <section class="card">
        <div class="card-head">
          <h2>${i18n.t('fivePrayers')} — ادا</h2>
        </div>
        <div id="prayer-list">
          ${PRAYERS.map((p) => {
            const item = d[p.key] || {};
            return `
              <div class="prayer-block ${item.done ? 'done' : ''}" data-key="${p.key}">
                <div class="pb-top">
                  <div class="prayer-icon">${ICONS[p.icon]}</div>
                  <div class="prayer-info">
                    <div class="prayer-name">${p.name}</div>
                    <div class="prayer-ar ar">${p.ar} · ${p.rakah}</div>
                  </div>
                  <div class="pb-actions">
                    <input class="check done-box" type="checkbox" ${item.done ? 'checked' : ''} aria-label="${p.name} ادا">
                  </div>
                </div>
              </div>`;
          }).join('')}
        </div>
        <div class="tip green">
          ${ICONS.sparkle}
          <span>هر نماز، یک قدم ارزشمند به‌سوی آرامش.</span>
        </div>
      </section>

      <!-- قضا -->
      <section class="card">
        <div class="card-head">
          <h2>${i18n.t('qadaTitle')}</h2>
        </div>
        <p class="muted" style="margin-bottom:10px;font-size:.78rem">${i18n.t('qadaHint')}</p>
        <div class="qada-list">
          ${PRAYERS.map((p, i) => {
            const q = qadaList[i] || {};
            return `
              <label class="qada-item ${q.done ? 'done' : ''}" data-qi="${i}">
                <input type="checkbox" class="qada-box" ${q.done ? 'checked' : ''}>
                <span class="qada-name">${p.name} (قضا)</span>
                <span class="muted" style="font-size:.7rem">${q.at ? faNum(q.at.slice(5, 10).split('-').reverse().join('/')) : ''}</span>
              </label>`;
          }).join('')}
        </div>
      </section>

      <!-- یادداشت -->
      <section class="card">
        <div class="card-head"><h2>${i18n.t('dailyNote')}</h2></div>
        <textarea class="input" id="prayer-note" rows="2" maxlength="500" placeholder="${i18n.t('dailyNotePh')}">${d.note || ''}</textarea>
        <div class="actions">
          <button class="btn btn-primary btn-sm" id="note-save">${ICONS.check} ${i18n.t('save')}</button>
        </div>
      </section>

      <!-- تقویم -->
      <section class="card calendar">
        <div class="cal-head">
          <button class="icon-btn" id="cal-prev" aria-label="ماه قبل">${ICONS.next}</button>
          <h3 id="cal-title"></h3>
          <button class="icon-btn" id="cal-next" aria-label="ماه بعد">${ICONS.back}</button>
        </div>
        <div class="cal-grid" id="cal-grid"></div>
        <div class="cal-legend">
          <span><i class="l-green"></i>نمازهای ثبت‌شده</span>
          <span><i class="l-gold"></i>قضا</span>
        </div>
      </section>

      <!-- تاریخچه -->
      <section class="card">
        <div class="card-head"><h2>تاریخچه ۱۴ روز اخیر</h2></div>
        <div id="history-list"></div>
      </section>

      <div class="actions">
        <a class="btn btn-soft btn-sm" href="/reports">${ICONS.chart} گزارش کامل</a>
        <button class="btn btn-ghost btn-sm" id="clear-day" ${isToday ? '' : 'hidden'}>${ICONS.trash} ${i18n.t('clearToday')}</button>
      </div>
    `;

    this.bind(dk);
    this.renderCalendar();
    this.renderHistory();
  },

  bind(dk) {
    const root = this.root;
    const isToday = dk === todayKey();

    // ناوبری روز
    root.querySelector('#day-prev').addEventListener('click', () => this.shiftDay(-1));
    root.querySelector('#day-next').addEventListener('click', () => this.shiftDay(1));
    root.querySelector('#day-today')?.addEventListener('click', () => {
      this.state.dateKey = todayKey();
      this.renderView();
    });

    // تیک ادا
    root.querySelectorAll('#prayer-list .prayer-block').forEach((el) => {
      const box = el.querySelector('.done-box');
      box.addEventListener('change', () => {
        Store.update('day:' + dk, (d) => {
          d[el.dataset.key] = {
            ...(d[el.dataset.key] || {}),
            done: box.checked,
            at: box.checked ? new Date().toISOString() : undefined
          };
          return d;
        });
        this.afterChange();
      });
    });

    // قضا
    root.querySelectorAll('.qada-item').forEach((el) => {
      const box = el.querySelector('.qada-box');
      box.addEventListener('change', () => {
        const qi = +el.dataset.qi;
        Store.update('day:' + dk, (d) => {
          if (!Array.isArray(d.qada)) d.qada = [];
          const at = box.checked ? dayKey() : undefined;
          d.qada[qi] = { done: box.checked, at };
          return d;
        });
        this.afterChange();
      });
    });

    // یادداشت
    root.querySelector('#note-save').addEventListener('click', () => {
      const v = root.querySelector('#prayer-note').value.trim().slice(0, 500);
      Store.update('day:' + dk, (d) => { d.note = v; return d; });
      toast(i18n.t('saved'));
    });

    // پاک‌کردن
    root.querySelector('#clear-day')?.addEventListener('click', async () => {
      const ok = await confirmDialog(i18n.t('clearTodayMsg'), { danger: true, okLabel: 'پاک شود' });
      if (!ok) return;
      Store.remove('day:' + dk);
      this.renderView();
    });

    // تقویم
    root.querySelector('#cal-prev').addEventListener('click', () => this.shiftMonth(-1));
    root.querySelector('#cal-next').addEventListener('click', () => this.shiftMonth(1));
  },

  afterChange() {
    // بررسی نشان‌ها در پس‌زمینه
    const stats = computeStats(Store, { dayKey, daysAgoKey, todayKey, keyToDate });
    const newly = checkAchievements(Store, stats);
    this.renderView();
    if (newly.length) toast('🏆 نشان جدید گرفتی!');
  },

  shiftDay(n) {
    const d = keyToDate(this.state.dateKey);
    d.setDate(d.getDate() + n);
    const k = dayKey(d);
    if (k > todayKey()) return;
    this.state.dateKey = k;
    this.renderView();
  },

  calMonth: null,
  renderCalendar() {
    const root = this.root;
    if (!this.calMonth) {
      const [jy, jm] = gregorianToJalali(...this.state.dateKey.split('-').map(Number));
      this.calMonth = { jy, jm };
    }
    const { jy, jm } = this.calMonth;
    const monthLen = jalaaliMonthLength(jy, jm);
    // اولین روز ماه شمسی → میلادی → روز هفته
    const [gy0, gm0, gd0] = jalaliToGregorian(jy, jm, 1);
    const first = new Date(gy0, gm0 - 1, gd0);
    const startDow = (first.getDay() + 1) % 7; // شنبه = 0
    const tk = todayKey();

    root.querySelector('#cal-title').textContent = `${MONTHS_FA[jm - 1]} ${faNum(jy)}`;
    const grid = root.querySelector('#cal-grid');
    let html = DOW.map((n) => `<div class="cal-dow">${n.slice(0, 2)}</div>`).join('');

    for (let i = 0; i < startDow; i++) html += '<div></div>';

    for (let day = 1; day <= monthLen; day++) {
      const [gy, gm, gd] = jalaliToGregorian(jy, jm, day);
      const k = `${gy}-${String(gm).padStart(2, '0')}-${String(gd).padStart(2, '0')}`;
      const d = getDay(k);
      let done = 0;
      PRAYERS.forEach((p) => { if (d[p.key]?.done) done++; });
      const hasQada = Array.isArray(d.qada) && d.qada.some((q) => q.done);
      const cls = [
        'cal-day',
        k > tk ? 'future' : '',
        k === tk ? 'today' : '',
        k === this.state.dateKey ? 'selected' : ''
      ].join(' ');
      html += `
        <div class="${cls}" data-date="${k}">
          ${hasQada ? '<span class="qada-dot"></span>' : ''}
          ${faNum(day)}
          <div class="dots">${'<i></i>'.repeat(done)}</div>
        </div>`;
    }
    grid.innerHTML = html;

    grid.querySelectorAll('.cal-day:not(.future)').forEach((el) => {
      el.addEventListener('click', () => {
        this.state.dateKey = el.dataset.date;
        const [jy2, jm2] = gregorianToJalali(...el.dataset.date.split('-').map(Number));
        this.calMonth = { jy: jy2, jm: jm2 };
        this.renderView();
      });
    });
  },

  shiftMonth(n) {
    if (!this.calMonth) {
      const [jy, jm] = gregorianToJalali(...this.state.dateKey.split('-').map(Number));
      this.calMonth = { jy, jm };
    }
    let { jy, jm } = this.calMonth;
    jm += n;
    while (jm > 12) { jm -= 12; jy++; }
    while (jm < 1) { jm += 12; jy--; }
    this.calMonth = { jy, jm };
    this.renderCalendar();
  },

  renderHistory() {
    const root = this.root;
    const list = root.querySelector('#history-list');
    let html = '';
    for (let i = 13; i >= 0; i--) {
      const k = daysAgoKey(i);
      const d = getDay(k);
      let done = 0, qada = 0;
      PRAYERS.forEach((p) => {
        if (d[p.key]?.done) done++;
      });
      if (Array.isArray(d.qada)) qada = d.qada.filter((q) => q.done).length;
      const date = keyToDate(k);
      const label = i === 0 ? i18n.t('today') : i === 1 ? i18n.t('yesterday') : i18n.formatDate(date, { weekday: 'long' });
      const hasData = done > 0 || qada > 0 || d.note;
      html += `
        <div class="history-row" style="display:flex;align-items:center;gap:10px;padding:9px 4px;border-bottom:1px solid var(--line);cursor:pointer" data-date="${k}">
          <span style="flex:1;font-size:.82rem">${label}</span>
          ${qada ? `<span class="badge gold">قضا ${faNum(qada)}</span>` : ''}
          <span class="num" style="font-weight:800;color:var(--deep);font-size:.85rem">${faNum(done)}/۵</span>
        </div>`;
    }
    list.innerHTML = html;
    list.querySelectorAll('.history-row').forEach((el) => {
      el.addEventListener('click', () => {
        this.state.dateKey = el.dataset.date;
        this.calMonth = new Date(keyToDate(el.dataset.date));
        this.renderView();
      });
    });
  }
};
