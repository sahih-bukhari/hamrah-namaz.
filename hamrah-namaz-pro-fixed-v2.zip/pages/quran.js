/* ===== صفحه قرآن کریم =====
 * - فهرست ۱۱۴ سوره با جستجو
 * - متن عربی + ترجمه فارسی (از API معتبر quran.com — بدون تولید خودکار)
 * - شماره آیات
 * - علاقه‌مندی و یادداشت آیات
 * - نشان‌گذاری آخرین آیه
 * - تنظیم فونت + حالت شب
 * - پیشرفت مطالعه
 */

import Store from '../js/core/store.js';
import i18n from '../js/core/i18n.js';
import { ICONS, faNum, toast } from '../js/utils/helpers.js';
import { SURAHS, fetchSurah } from '../js/data/quran.js';

export default {
  state: { view: 'list', surah: null, query: '', night: false, fontScale: 1 },

  render(root) {
    this.root = root;
    const q = Store.get('quran', {});
    this.state.night = q.night || false;
    this.state.fontScale = q.fontScale || 1;
    this.favs = new Set((q.favs || []).map((f) => f.key));
    this.notes = q.notes || {};
    this.last = q.last || null;
    this.readSurahs = new Set(q.readSurahs || []);
    this.renderView();
  },

  save() {
    Store.set('quran', {
      night: this.state.night,
      fontScale: this.state.fontScale,
      favs: [...this.favs].map((key) => ({ key })),
      notes: this.notes,
      last: this.last,
      readSurahs: [...this.readSurahs]
    });
  },

  renderView() {
    const root = this.root;
    if (this.state.view === 'reader' && this.state.surah) {
      this.renderReader();
      return;
    }

    const q = this.state.query.trim();
    const list = SURAHS.filter(
      (s) =>
        !q ||
        s.fa.includes(q) ||
        s.ar.includes(q) ||
        String(s.n) === q ||
        faNum(s.n) === q
    );

    const totalAyahs = SURAHS.reduce((a, s) => a + s.ayahs, 0);
    const readAyahs = SURAHS.filter((s) => this.readSurahs.has(s.n)).reduce((a, s) => a + s.ayahs, 0);

    root.innerHTML = `
      <!-- پیشرفت -->
      <div class="card" style="padding:14px">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="flex:1">
            <div style="display:flex;justify-content:space-between;font-size:.78rem;margin-bottom:5px">
              <span style="font-weight:700">پیشرفت مطالعه</span>
              <span class="muted">${faNum(this.readSurahs.size)} از ۱۱۴ سوره</span>
            </div>
            <div class="bar gold"><i style="width:${(this.readSurahs.size / 114) * 100}%"></i></div>
          </div>
        </div>
      </div>

      <!-- جستجو -->
      <div class="quran-search">
        ${ICONS.search}
        <input class="input" id="quran-search" type="search" placeholder="جستجوی سوره (نام فارسی، عربی یا شماره)..." value="${q}">
      </div>

      <!-- فهرست -->
      <div class="surah-list">
        ${list.map((s) => {
          const read = this.readSurahs.has(s.n);
          const isLast = this.last?.surah === s.n;
          return `
            <div class="surah-item ${read ? 'read' : ''}" data-n="${s.n}">
              <div class="s-num">${faNum(s.n)}</div>
              <div class="s-info">
                <div class="s-fa">${s.fa} ${isLast ? '<span class="badge green" style="font-size:.6rem">آخرین مطالعه</span>' : ''}</div>
                <div class="s-meta">${s.place} · ${faNum(s.ayahs)} آیه</div>
              </div>
              <div class="s-ar ar">${s.ar}</div>
              ${read ? `<span class="read-badge">${ICONS.check}</span>` : ''}
            </div>`;
        }).join('')}
        ${list.length === 0 ? '<div class="empty">سوره‌ای یافت نشد</div>' : ''}
      </div>
    `;

    const searchEl = root.querySelector('#quran-search');
    searchEl.addEventListener('input', (e) => {
      this.state.query = e.target.value;
      // فقط فهرست را به‌روز کن (بدون رندر مجدد کامل)
      const list = SURAHS.filter(
        (s) =>
          !this.state.query.trim() ||
          s.fa.includes(this.state.query.trim()) ||
          s.ar.includes(this.state.query.trim()) ||
          String(s.n) === this.state.query.trim() ||
          faNum(s.n) === this.state.query.trim()
      );
      const container = root.querySelector('.surah-list');
      container.innerHTML = list.length
        ? list.map((s) => {
            const read = this.readSurahs.has(s.n);
            const isLast = this.last?.surah === s.n;
            return `
              <div class="surah-item ${read ? 'read' : ''}" data-n="${s.n}">
                <div class="s-num">${faNum(s.n)}</div>
                <div class="s-info">
                  <div class="s-fa">${s.fa} ${isLast ? '<span class="badge green" style="font-size:.6rem">آخرین مطالعه</span>' : ''}</div>
                  <div class="s-meta">${s.place} · ${faNum(s.ayahs)} آیه</div>
                </div>
                <div class="s-ar ar">${s.ar}</div>
                ${read ? `<span class="read-badge">${ICONS.check}</span>` : ''}
              </div>`;
          }).join('')
        : '<div class="empty">سوره‌ای یافت نشد</div>';
      container.querySelectorAll('.surah-item').forEach((el) => {
        el.addEventListener('click', () => this.openSurah(+el.dataset.n));
      });
    });

    root.querySelectorAll('.surah-item').forEach((el) => {
      el.addEventListener('click', () => this.openSurah(+el.dataset.n));
    });
  },

  async openSurah(n) {
    this.state.view = 'reader';
    this.state.surah = n;
    this.renderReader();
    await this.loadSurahContent(n);
  },

  renderReader() {
    const root = this.root;
    const s = SURAHS.find((x) => x.n === this.state.surah);
    const night = this.state.night;

    root.innerHTML = `
      <div class="quran-reader active ${night ? 'quran-night' : ''}" id="reader-wrap">
        <div class="reader-head">
          <button class="icon-btn" id="reader-back" aria-label="بازگشت">${ICONS.next}</button>
          <div style="flex:1;text-align:center">
            <h2>${s.fa}</h2>
            <div class="muted" style="font-size:.72rem">${s.place} · ${faNum(s.ayahs)} آیه</div>
          </div>
          <div class="reader-tools">
            <button class="icon-btn font-btn" id="font-dec" aria-label="کوچک‌تر">A-</button>
            <button class="icon-btn font-btn" id="font-inc" aria-label="بزرگ‌تر">A+</button>
            <button class="icon-btn ${night ? 'active' : ''}" id="night-toggle" aria-label="حالت شب">${night ? ICONS.sun : ICONS.moon}</button>
          </div>
        </div>
        <div id="ayah-list">
          <div class="empty">${ICONS.quran}<p>در حال بارگذاری سوره...</p></div>
        </div>
      </div>
    `;

    root.querySelector('#reader-back').addEventListener('click', () => {
      this.state.view = 'list';
      this.state.surah = null;
      this.save();
      this.renderView();
    });

    root.querySelector('#font-inc').addEventListener('click', () => {
      this.state.fontScale = Math.min(this.state.fontScale + 0.1, 1.6);
      this.applyFont();
      this.save();
    });
    root.querySelector('#font-dec').addEventListener('click', () => {
      this.state.fontScale = Math.max(this.state.fontScale - 0.1, 0.8);
      this.applyFont();
      this.save();
    });
    root.querySelector('#night-toggle').addEventListener('click', () => {
      this.state.night = !this.state.night;
      const wrap = root.querySelector('#reader-wrap');
      wrap.classList.toggle('quran-night', this.state.night);
      root.querySelector('#night-toggle').innerHTML = this.state.night ? ICONS.sun : ICONS.moon;
      root.querySelector('#night-toggle').classList.toggle('active', this.state.night);
      this.save();
    });

    this.applyFont();
  },

  applyFont() {
    const wrap = this.root.querySelector('#reader-wrap');
    if (wrap) {
      wrap.style.setProperty('--quran-font', `${(1.3 * this.state.fontScale).toFixed(2)}rem`);
      wrap.querySelectorAll('.a-ar').forEach((el) => {
        el.style.fontSize = `${(1.3 * this.state.fontScale).toFixed(2)}rem`;
      });
    }
  },

  async loadSurahContent(n) {
    const list = this.root.querySelector('#ayah-list');
    try {
      const data = await fetchSurah(n);
      if (this.state.surah !== n) return; // کاربر جابه‌جا شده

      // علامت‌گذاری سوره به‌عنوان مطالعه‌شده
      this.readSurahs.add(n);
      this.save();

      list.innerHTML = data.verses.map((v) => {
        const key = `${n}:${v.ayah}`;
        const faved = this.favs.has(key);
        const note = this.notes[key];
        return `
          <div class="ayah ${faved ? 'faved' : ''}" data-key="${key}">
            <span class="a-num">${faNum(v.ayah)}</span>
            <div class="a-ar ar">${v.ar}</div>
            ${v.tr ? `<div class="a-tr">${v.tr}</div>` : ''}
            ${note ? `<div class="a-note">${this.escapeHtml(note)}</div>` : ''}
            <div class="a-actions">
              <button class="icon-btn fav-btn ${faved ? 'faved' : ''}" data-act="fav" aria-label="علاقه‌مندی">${ICONS.heart}</button>
              <button class="icon-btn" data-act="note" aria-label="یادداشت">${ICONS.note}</button>
              <button class="icon-btn" data-act="copy" aria-label="کپی">${ICONS.copy}</button>
            </div>
          </div>`;
      }).join('');

      // آخرین آیه
      this.last = { surah: n, ayah: data.verses[data.verses.length - 1].ayah, at: Date.now() };
      this.save();

      this.bindAyahs();
      this.applyFont();
    } catch (e) {
      list.innerHTML = `
        <div class="empty">
          ${ICONS.cloud}
          <p>اتصال به اینترنت برای بارگذاری متن سوره لازم است.</p>
          <p class="muted" style="font-size:.75rem;margin-top:6px">${i18n.t('offline')}</p>
        </div>`;
    }
  },

  bindAyahs() {
    const list = this.root.querySelector('#ayah-list');
    list.querySelectorAll('.ayah').forEach((el) => {
      const key = el.dataset.key;
      const [s, a] = key.split(':').map(Number);

      el.querySelector('[data-act="copy"]').addEventListener('click', async () => {
        const ar = el.querySelector('.a-ar').textContent;
        try {
          await navigator.clipboard.writeText(ar);
          toast(i18n.t('copied'));
        } catch (e) {
          toast('کپی ممکن نشد', 'error');
        }
      });

      el.querySelector('[data-act="fav"]').addEventListener('click', () => {
        if (this.favs.has(key)) this.favs.delete(key);
        else this.favs.add(key);
        el.classList.toggle('faved', this.favs.has(key));
        el.querySelector('[data-act="fav"]').classList.toggle('faved', this.favs.has(key));
        this.save();
      });

      el.querySelector('[data-act="note"]').addEventListener('click', () => {
        const existing = this.notes[key] || '';
        const ta = document.createElement('textarea');
        ta.className = 'input';
        ta.rows = 3;
        ta.maxLength = 500;
        ta.placeholder = 'یادداشت شخصی درباره این آیه...';
        ta.value = existing;

        import('../js/utils/helpers.js').then(({ openModal }) => {
          openModal({
            title: `یادداشت — آیه ${faNum(a)}`,
            body: ta,
            actions: [
              {
                label: 'ذخیره', cls: 'btn-primary',
                onClick: () => {
                  const v = ta.value.trim();
                  if (v) this.notes[key] = v;
                  else delete this.notes[key];
                  this.save();
                  this.loadSurahContent(this.state.surah);
                  return true;
                }
              },
              { label: 'انصراف', cls: 'btn-ghost' }
            ]
          });
        });
      });
    });
  },

  escapeHtml(s) {
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }
};
