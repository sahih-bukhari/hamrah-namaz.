-- =====================================================
-- همراه نماز من — ساختار دیتابیس Supabase (PostgreSQL)
-- اجرای این فایل در SQL Editor کنسول Supabase
-- =====================================================

-- ---------- جداول ----------

-- ثبت نمازهای ادا (هر روز، هر نماز یک ردیف)
create table if not exists public.prayer_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  prayer text not null check (prayer in ('fajr','dhuhr','asr','maghrib','isha')),
  done boolean not null default true,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, day, prayer)
);

-- نمازهای قضا (جبران)
create table if not exists public.qada_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  prayer text not null,
  original_day date,
  note text,
  created_at timestamptz not null default now()
);

-- تاریخچه تسبیحات
create table if not exists public.tasbih_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null default current_date,
  dhikr text not null,
  count integer not null check (count > 0),
  created_at timestamptz not null default now()
);

-- اهداف شخصی
create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  schedule text,
  time text,
  completed boolean not null default false,
  done_dates date[] not null default '{}',
  created_at timestamptz not null default now()
);

-- علاقه‌مندی‌های اذکار (id ذکر)
create table if not exists public.dhikr_favs (
  user_id uuid not null references auth.users(id) on delete cascade,
  dhikr_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, dhikr_id)
);

-- علاقه‌مندی‌ها و یادداشت‌های آیات قرآن
create table if not exists public.quran_bookmarks (
  user_id uuid not null references auth.users(id) on delete cascade,
  surah integer not null,
  verse integer not null,
  is_fav boolean not null default false,
  note text,
  created_at timestamptz not null default now(),
  primary key (user_id, surah, verse)
);

-- پیشرفت مطالعه سوره‌ها
create table if not exists public.quran_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  surah integer not null,
  last_verse integer,
  read boolean not null default false,
  updated_at timestamptz not null default now(),
  primary key (user_id, surah)
);

-- درس‌های آموزشی تکمیل‌شده
create table if not exists public.learn_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null,
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

-- تنظیمات کاربر
create table if not exists public.settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  language text not null default 'fa',
  theme text not null default 'system',
  font_scale numeric not null default 1,
  haptics boolean not null default true,
  sound boolean not null default false,
  updated_at timestamptz not null default now()
);

-- صف همگام‌سازی (برای آفلاین‌فرست)
create table if not exists public.sync_queue (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  key text not null,
  value jsonb,
  created_at timestamptz not null default now()
);

-- ---------- ایندکس‌ها ----------
create index if not exists idx_prayer_logs_user_day on public.prayer_logs (user_id, day desc);
create index if not exists idx_tasbih_user_day on public.tasbih_history (user_id, day desc);
create index if not exists idx_qada_user_day on public.qada_logs (user_id, day desc);

-- ---------- Row Level Security ----------
alter table public.prayer_logs enable row level security;
alter table public.qada_logs enable row level security;
alter table public.tasbih_history enable row level security;
alter table public.goals enable row level security;
alter table public.dhikr_favs enable row level security;
alter table public.quran_bookmarks enable row level security;
alter table public.quran_progress enable row level security;
alter table public.learn_progress enable row level security;
alter table public.settings enable row level security;
alter table public.sync_queue enable row level security;

-- هر کاربر فقط داده‌های خودش را می‌بیند/تغییر می‌دهد
create policy "own prayer_logs" on public.prayer_logs
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own qada_logs" on public.qada_logs
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own tasbih_history" on public.tasbih_history
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own goals" on public.goals
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own dhikr_favs" on public.dhikr_favs
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own quran_bookmarks" on public.quran_bookmarks
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own quran_progress" on public.quran_progress
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own learn_progress" on public.learn_progress
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own settings" on public.settings
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "own sync_queue" on public.sync_queue
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------- به‌روزرسانی خودکار updated_at ----------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists trg_prayer_touch on public.prayer_logs;
create trigger trg_prayer_touch before update on public.prayer_logs
  for each row execute function public.touch_updated_at();

drop trigger if exists trg_settings_touch on public.settings;
create trigger trg_settings_touch before update on public.settings
  for each row execute function public.touch_updated_at();
